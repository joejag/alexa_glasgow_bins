// var APP_ID = "amzn1.echo-sdk-ams.app.amzn1.ask.skill.d83a7f74-56e4-4cd7-8f03-bfebd5c47662"; //replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";

var AlexaSkill = require('./AlexaSkill');

var GlasgowBins = function () {
    AlexaSkill.call(this, APP_ID);
};

GlasgowBins.prototype = Object.create(AlexaSkill.prototype);

GlasgowBins.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    var speechOutput = "Welcome to the Glasgow bins, you can say hello";
    var repromptText = "You can say hello";
    response.ask(speechOutput, repromptText);
};

GlasgowBins.prototype.intentHandlers = {
    // register custom intent handlers
    "GlasgowBinsIntent": function (intent, session, response) {
        response.tellWithCard("It's the blue and purple ones on Wednesday!", "Hello World", "Hello World!");
    },
    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("You can say hello to me!", "You can say hello to me!");
    }
};

GlasgowBins.prototype.constructor = GlasgowBins;
GlasgowBins.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {};
GlasgowBins.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {};

exports.handler = function (event, context) {
    var glasgowBins = new GlasgowBins();
    glasgowBins.execute(event, context);
};
